package rush.hour;
/**
 * Main class of the project
 * @author Xavier Leblond, Kevin Meyer, Raphaël Voirin, Meryem Fourkane.
 * @version 2014.03.09
*/
	
public class RushHour3{	

	/** 
	*  Méthode main permettant de lancer le jeu
	*/
	public static void main (String args[]){
		Player.getJoueur();
		ParkingFactory.getParkFactor();
	}
}
