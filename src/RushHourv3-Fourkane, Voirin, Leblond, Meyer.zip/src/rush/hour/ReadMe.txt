﻿Auteurs: Xavier LEBLOND, Raphael VOIRIN, Meryem FOURKANE, Kevin MEYER

Les bugs de la version précédente (score et machine virtuelle qui conserve les ressources après l'arret du jeu) n'ont pas pu être corrigés.
Les classes ParkingConfiguration et ParkingResolver ont été créées avec les méthodes demandées et des ajouts ont été fait a niveau de l'IHM (ajout du bouton Help), du ParkingFactory (création d'un getter pour le Parking associé), du BouttonCtrl (ajout d'une action associée à l'appui sur le bouton HELP) et du Parking (ajout de deux getters pour la liste des Vehicules et le ParkingController).
Néansmoins, la partie concernant l'aide ne semble pas fonctionner (pas d'action pour une solution en 1 mouvement et un bloquage du jeu pour des solutions en plus de 1 mouvement).